# Taller de Maquetación

Repositorio de proyectos del taller de maquetación de @jonmircha en YouTube.

## Proyectos

| Proyecto                             |                                                          |                                                                                      |
| ------------------------------------ | -------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| _Landing Page_ de tipo Portafolio-CV | [Ver Video](https://www.youtube.com/watch?v=ErtR07GLq54) | [Ver Proyecto](https://jonmircha.github.io/youtube-taller-maquetacion/portafolio-cv) |
